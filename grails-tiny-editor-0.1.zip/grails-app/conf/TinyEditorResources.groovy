// Define the resources for exposure via Resources plugin
modules = {
	tiny {
		resource id:'main', url:[plugin:'tiny-editor', dir:'js/tiny_mce', file:'tiny_mce.js']
	}

}